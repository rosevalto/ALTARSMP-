    MODEL_SHADER(1) {
        #moj_import <skyboxes/clouds.glsl>
        return;
    }
