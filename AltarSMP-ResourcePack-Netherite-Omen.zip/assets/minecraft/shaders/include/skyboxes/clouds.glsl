// Stormy cloud box for Arbiter's Judgement — churning grey-violet clouds.
fragColor.a = 1;
vec3 cloudLight = rgba(214, 220, 238, 1).rgb;
vec3 cloudDark  = rgba(70, 64, 104, 1).rgb;
float scaling = 9.0;
float n = noise(worldDirection * scaling + noise(worldDirection * scaling * 2.0
        - noise(worldDirection * scaling * -0.5 + GameTime * -700) * 4.0
        + GameTime * 350) * 0.5 + GameTime * 320 + vec3(0,-1600,0)*GameTime);
n = clamp(pow(n, 0.75), 0.0, 1.0);
fragColor.rgb = mix(cloudDark, cloudLight, n);
fragColor = applyFog(fragColor, 0.25);
